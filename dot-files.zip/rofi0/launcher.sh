#!/bin/bash

theme="$HOME/.config/rofi/launcher.rasi"

rofi -show drun \
    -theme ${theme}
