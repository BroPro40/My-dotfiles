-- Подключение плагинов
require("core.plugins")
require("plugins.ruscmd")
require("plugins.lualine")

-- Цветовая схема
--require("plugins.nord")
--require("plugins.catppuccin")
require("plugins.rosepine")

--==--==--==--==--==--==--==--==--==--

-- Активация читов
local g = vim.g
local o = vim.o
local keymap = vim.keymap
require('lualine').setup()

-- Чувство стиля
o.number = true
o.relativenumber = false
o.cursorline = true
o.laststatus = 1
o.termguicolors = true

-- Бекапы
o.backup = false
o.writebackup = false
o.swapfile = false

-- Настройки удобства
o.mouse = "a"
o.mousefocus = true
o.showmode = true
o.wrap = false
o.virtualedit = "block"
o.shell = "/bin/zsh"

-- Буфер обмена
o.clipboard = "unnamedplus"

-- Табуляция
o.tabstop = 4
o.softtabstop = 4
o.shiftwidth = 4
o.expandtab = true
o.smartindent = true
o.smarttab = true

-- Я хз, что это. Однако оно будет здесь...
vim.cmd([[highlight clear LineNr]])
vim.cmd([[highlight clear SignColumn]])

-- Бездна
